$( function() {
    $( "#p5" ).draggable();
      
} );